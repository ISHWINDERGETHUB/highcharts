#### Expected behaviour


#### Actual behaviour


#### Reproduction steps
<!-- Please describe how to reproduce the issue -->

#### Editor version
<!--- Which version of the editor are you using? -->

#### Affected browser(s)

<!--- 

Please Note:

If you have general questions rather then issues, please reach out to us via
our other support channels: https://www.highcharts.com/support

-->
